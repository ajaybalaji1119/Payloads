## Units

- Akagi, x64/x86-32 main executable file, contain payload/data units.
- Akatsuki, x64 payload, WOW64 logger.
- Fubuki, x64/x86-32 payload, general purpose.
- Kamikaze, data, MMC snap-in.
- Naka, x64/x86-32 compressor for other payload/data units.
- Yuubari, x64 UAC info data dumper.

## Other

- Shared, contain headers and source code shared between several projects.
