using System;
using System.IO;

namespace PoshC2DynamicCode {

    public class Program
    {

        public static void Main(string[] args){
            // Code goes here, e.g:
            Console.WriteLine("Dynamic Code executed successfully");
        }

    }

}
